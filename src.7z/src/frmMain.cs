﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DriveFrame
{
    public partial class frmMain : Form
    {
        Image photo;
        public frmMain()
        {
            InitializeComponent();

            if (DwmAPI.DwmIsCompositionEnabled())
            {
                // Paint the glass effect.
                DwmAPI.MARGINS margins;
                //this.Opacity = 0;
                //this.Opacity = 1;
                margins = new DwmAPI.MARGINS();
                margins.Top = 0;
                margins.Left = -1;
                DwmAPI.DwmExtendFrameIntoClientArea(this.Handle, ref margins);
            }

            photo = new Bitmap(this.ClientSize.Width, this.ClientSize.Height, PixelFormat.Format32bppArgb);
            Graphics graphicsObj = Graphics.FromImage(photo);
            graphicsObj.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;

            //graphicsObj.Clear(Color.Black);
            //graphicsObj.DrawImage(new Bitmap(@"f:\E\zPhotoFrame\cell.png"), 0, 0);
            graphicsObj.DrawString("asfasfqw fqw5555", new  Font(this.Font.FontFamily, 13f), new SolidBrush(Color.White), new PointF(100, 100));
            graphicsObj.Dispose();
            photo.Save("a.png");
            this.BackgroundImage = photo;
        }

        private void frmMain_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Win32API.ReleaseCapture();
                Win32API.SendMessage(this.Handle, Win32API.WM_NCLBUTTONDOWN, Win32API.HT_CAPTION, 0);
            }
        }

        private void frmMain_Paint(object sender, PaintEventArgs e)
        {
            //var image = new Bitmap(@"f:\E\zPhotoFrame\cell.png");
            //e.Graphics.DrawImage(image, 0, 0, image.Width, image.Height);
        }
    }
}
